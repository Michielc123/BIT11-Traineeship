#' Bendability profile of DNA sequence
#'
#' Splits sequence(s) into \code{(k+2)}-mers with two-nucleotide overlap and calculates average
#' bendability per \code{(k+2)}-mer according to the chosen scale. Plots the result.
#'
#' @param sequences A DNAStringSet object or a character vector.
#' @param scale One from "con", "conrigid", "dnase", "dnaserigid", "nuc", "nucrigid",
#'    or the name for a user-supplied one.
#' @param k Number of consecutive trinucleotides for which to calculate the average
#'    bendability coefficient.
#' @param plot.it Whether to plot the bendability profile(s) or not. Defaults to TRUE.
#' @param smt Degree of line smoothing. Between 0 and 1, defaults to 0 (no smoothing).
#' @param bendtable (optional) User-supplied bendability scale. See Details.
#'
#' @return A data.table, or a plot and a data.table. Each input sequence is represented
#' by one row in data.table, where columns contain average bendability coefficients for
#' consecutive \code{(k+2)}-mers with two-nucleotide overlaps.
#' @details Parameter \strong{k} is defined as number of consecutive trinucleotides rather
#' than number of nucleotides (or window size) because a bendability coefficient is
#' defined for a trinucleotide. Size of window is actually \code{(k+2)} nucleotides.
#'
#' If you wish to use a scale other than the six provided with the package, you can do so
#' by providing a two-column data.table \strong{bendtable}. First column should contain
#' all 64 trinucleotides \emph{in alphabetical order}, in uppercase, as type character.
#' Second column is bendability coefficients as type numeric (be sure to use decimal point,
#' not decimal comma). You can provide a scale name to be used in plot title via parameter
#' \strong{scale}.
#' @export
#'
#' @examples
#' BendabilityProfile(bendDNA:::query_long, scale="con", k=30)
#'
#' # plotting 15 random sequences from MatchBendability output:
#' dt <- MatchBendability(bendDNA:::query, scale="con", k=1, tolerance=0.5)
#' ind <- sample.int(nrow(dt), 15)
#' BendabilityProfile(dt$sequence[ind], scale="con", k=1, smt=0.2)
BendabilityProfile <- function(sequences, scale="myscale", k, plot.it=TRUE, smt=0, bendtable=NULL) {

  # get bendability table, if it's not already provided:
  if(is.null(bendtable)) bendtable <- scales[, c("V1", scale), with=F]
  setnames(bendtable, c("ref", "refbend"))

  sq <- as.character(sequences)

  # funtion Yaxis returns (average) bendability coefficients given one sequence:
  Yaxis <- function(query, k) {
    trinucleotides <- data.table(stringr::str_sub(query, seq(1, stringr::str_length(query)-2, 1), seq(3, stringr::str_length(query), 1)))
    bends <- bendtable[trinucleotides, on=list(ref=V1), nomatch=0]$refbend
    if(k==1) { means <- bends
    } else { means <- frollmean(bends, k, fill=NA, algo="fast", align="right")[seq(k, stringr::str_length(query)-2, k)] }
    return(means)
  }

  # apply function Yaxis to all sequences:
  l <- lapply(sq, Yaxis, k)
  dt <- rbindlist(lapply(l, function(x) data.table(t(x))), fill = TRUE)
  names(dt) <- as.character(1:ncol(dt))

  if(!is.null(names(sequences))) { out <- cbind(as.data.table(names(sequences)), dt)
  } else { out <- cbind(as.data.table(rownames(dt)), dt) }

  if(plot.it==TRUE) {

    # adjust format for plotting:
    melted <- melt(t(dt))
    names(melted) <- c("position", "sequence", "value")
    melted <- melted[!(is.na(melted$value)), ]
    melted$sequence <- as.factor(melted$sequence)

    # plot it:
    plot <- ggplot(melted, aes(x = position, y = value, group = sequence, col = sequence)) +
      ggformula::geom_spline(spar = smt) +
      labs(x = "\nWindow", y = "Bendability\n", colour = NULL) +
      ggtitle(paste0("Average bendability on window size ", k+2, ", scale ", scale)) +
      theme(plot.title = element_text(hjust = 0.5, size = 35),
            legend.text = element_text(size = 20),
            legend.key.size = unit(0.8,"cm"),
            plot.margin = unit(c(1,1,1,1), "cm"),
            legend.margin = margin(0,0,0,100),
            axis.text.x = element_text(size = 30, margin = margin(c(20,0,0,0))),
            axis.text.y = element_text(size = 30, margin = margin(c(0,20,0,0))),
            axis.title = element_text(size = 30)) +
      guides(col = guide_legend(ncol = 1))

    return(list(out, plot))

  } else { return(out) }

}
utils::globalVariables(c("V1", "value", "position"))
