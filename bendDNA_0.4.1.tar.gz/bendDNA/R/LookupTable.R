#' Average bendability coefficients of all possible k-mers
#'
#' Produces all possible \code{(k+2)}-mers for a given k and calculates their average bendability
#' coefficients. Upper limit for k is determined by the size of available RAM.
#'
#' @param scale One from "con", "conrigid", "dnase", "dnaserigid", "nuc", "nucrigid"
#'    (or omitted if a bendtable is provided).
#' @param k Number of consecutive trinucleotides for which to calculate the average
#'    bendability coefficient.
#' @param sequence.out Whether to output \code{(k+2)}-mer sequences (TRUE) or indexes of
#'    alphabetically sorted permutations (FALSE). Defaults to FALSE.
#' @param bendtable (optional) User-supplied bendability scale. See Details.
#'
#' @return A four-column data.table:
#' \itemize{
#'  \item{sequence} : {sequence of length \code{k+2}}
#'  \item{index} : {alternatively, index of permutation}
#'  \item{Lbend} : {average bendability}
#'  \item{pref} : {first two nucleotides of sequence/permutation}
#'  \item{suff} : {last two nucleotides of sequence/permutation}
#' }
#' @details Parameter \strong{k} is defined as number of consecutive trinucleotides rather
#' than number of nucleotides (or window size) because a bendability coefficient is
#' defined for a trinucleotide. Size of such window is actually \code{k+2} nucleotides.
#'
#' Due to memory restrictions, setting \strong{sequence.out} to FALSE is recommended for
#' higher values of k. Sequences corresponding to permutation indexes can easily
#' be retrieved using function \code{\link[arrangements]{permutations}} from
#' package \code{\link[arrangements]{arrangements-package}}.
#'
#' Dinucleotide prefixes and suffixes are represented with numbers 1-16 (corresponding
#' to their position when ordered alphabetically) to facilitate later matching and
#' reduce memory requirements.
#'
#' If you wish to use a scale other than the six provided with the package, you can do so
#' by providing a two-column data.table \strong{bendtable}. First column should contain
#' all 64 trinucleotides \emph{in alphabetical order}, in uppercase, as type character.
#' Second column is bendability coefficients as type numeric (be sure to use decimal point,
#' not decimal comma). Omit parameter scale from function call in this case.
#' @export
#'
#' @examples
#' LookupTable("dnase", 1, sequence.out=TRUE)
#' LookupTable("con", 7, sequence.out=FALSE)
#'
#' # retrieving the 1000st, 50000th, 100000th and 200000th permutation:
#' ind <- c(1000, 50000, 100000, 200000)
#' dna <- c("A","C","G","T")
#' apply(arrangements::permutations(dna, 7+2, replace=TRUE, index=ind), 1, paste, collapse="")
LookupTable <- function(scale, k, sequence.out=F, bendtable=NULL) {
  # calculates average bendability coefficient for all possible (k+2)mers

  # create table of bendability coefficients, unless it's provided by the user:
  if(is.null(bendtable)) bendtable <- scales[, c("V1", scale), with=F]
  setnames(bendtable, c("ref", "refbend"))

  # due to periodic nature of all permutations of k+2 nucleotides, sum of bendability coefficients per permutation
  # can be calculated as follows:
  LookupVector <- function(bendtable, k) {
    if(k==1) v <- bendtable$refbend
    else v <- rep(LookupVector(bendtable, k-1), each=4) + bendtable$refbend
    return(v)
  }

  # sequences are saved immediately if k=1. for bigger ks, indexes of all permutations are stored in memory and
  # translated to sequences only if requested. averages calculated if needed.
  if(k==1) {
    lookup <- bendtable[, `:=`(sequence=ref, Lbend=refbend, pref=rep(1:16, each=4), suff=rep(1:16, times=4))][, c(3:6)]
  } else {
    lookup <- data.table(LookupVector(bendtable, k))
    lookup <- cbind(seq(nrow(lookup)), lookup/k, rep(1:16, each=(4^(k+2))/16), rep(1:16, times=(4^(k+2))/16))
    setnames(lookup, c("index", "Lbend", "pref", "suff"))
  }

  # "translate" indexes to sequences if requested:
  if((k!=1) && (sequence.out==T)) {
    sequences <- apply(arrangements::permutations(c("A", "C", "G", "T"), k+2, replace=T, index=lookup$index), 1, paste, collapse="")
    lookup <- lookup[, index:=sequences]
    setnames(lookup, "index", "sequence")
  }

  # lookup table contains sequence or permutation index, bendability coefficient, and suffix and prefix
  return(lookup)
}
utils::globalVariables(c("scales", "ref", "refbend", "Lbend"))
