#' Scales for trinucleotide bendability coefficients.
#'
#' Available scales are "con", "conrigid", "dnase", "dnaserigid", "nuc", "nucrigid".
"scales"
